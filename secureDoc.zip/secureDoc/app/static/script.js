let token = '';

function login() {
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;

  fetch('/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password })
  }).then(res => res.json())
    .then(data => {
      if (data.access_token) {
        token = data.access_token;
        document.getElementById('login-section').style.display = 'none';
        document.getElementById('upload-section').style.display = 'block';
        loadFiles();
      } else {
        alert('Login failed');
      }
    });
}

function uploadFile() {
  const file = document.getElementById('file').files[0];
  const formData = new FormData();
  formData.append('file', file);

  fetch('/upload', {
    method: 'POST',
    headers: { 'Authorization': 'Bearer ' + token },
    body: formData
  }).then(res => res.json())
    .then(data => {
      alert(data.message);
      loadFiles();
    });
}

function loadFiles() {
  fetch('/my-files', {
    headers: { 'Authorization': 'Bearer ' + token }
  }).then(res => res.json())
    .then(files => {
      const list = document.getElementById('file-list');
      list.innerHTML = '';
      files.forEach(f => {
        const li = document.createElement('li');
        li.innerHTML = `
          ${f.filename}
          <button onclick="downloadFile(${f.id})">Download</button>
          <button onclick="deleteFile(${f.id})">Delete</button>
        `;
        list.appendChild(li);
      });
    });
}

function downloadFile(id) {
  window.open(`/download/${id}?token=${token}`, '_blank');
}

function deleteFile(id) {
  fetch(`/delete/${id}`, {
    method: 'DELETE',
    headers: { 'Authorization': 'Bearer ' + token }
  }).then(res => res.json())
    .then(data => {
      alert(data.message);
      loadFiles();
    });
}
